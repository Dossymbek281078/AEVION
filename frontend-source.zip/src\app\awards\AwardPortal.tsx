"use client";

import Link from "next/link";
import type { CSSProperties } from "react";
import { useEffect, useState } from "react";
import { Wave1Nav } from "@/components/Wave1Nav";
import { apiUrl } from "@/lib/apiBase";

type RecentArtifact = {
  id: string;
  submissionTitle?: string;
  versionNo?: number;
  artifactType?: string;
  createdAt?: string;
};

const btn: CSSProperties = {
  display: "inline-block",
  padding: "14px 22px",
  borderRadius: 12,
  fontWeight: 800,
  fontSize: 15,
  textDecoration: "none",
  textAlign: "center" as const,
};

type PlanetStats = {
  eligibleParticipants: number;
  distinctVotersAllTime: number;
  certifiedArtifactVersions: number;
  generatedAt?: string;
  awardSubmissions: number;
  awardCertified: number;
};

export function AwardPortal({ variant }: { variant: "music" | "film" }) {
  const isMusic = variant === "music";
  const [stats, setStats] = useState<PlanetStats | null>(null);
  const [statsErr, setStatsErr] = useState<string | null>(null);
  const [recent, setRecent] = useState<RecentArtifact[]>([]);

  useEffect(() => {
    let cancelled = false;
    const prefix = isMusic ? "aevion_award_music" : "aevion_award_film";
    const at = isMusic ? "music" : "movie";
    (async () => {
      try {
        const [r1, r2, r3] = await Promise.all([
          fetch(apiUrl("/api/planet/stats")),
          fetch(
            `${apiUrl("/api/planet/stats")}?productKeyPrefix=${encodeURIComponent(prefix)}`,
          ),
          fetch(
            `${apiUrl("/api/planet/artifacts/recent")}?limit=8&productKeyPrefix=${encodeURIComponent(prefix)}&artifactType=${at}`,
          ),
        ]);
        const j1 = await r1.json().catch(() => null);
        const j2 = await r2.json().catch(() => null);
        const j3 = await r3.json().catch(() => null);
        if (!r1.ok) throw new Error(j1?.error || "stats failed");
        if (!r2.ok) throw new Error(j2?.error || "scoped stats failed");
        const scoped = j2.scopedToProductKeyPrefix;
        if (!cancelled) {
          setStats({
            eligibleParticipants: j1.eligibleParticipants ?? 0,
            distinctVotersAllTime: j1.distinctVotersAllTime ?? 0,
            certifiedArtifactVersions: j1.certifiedArtifactVersions ?? 0,
            generatedAt: j1.generatedAt,
            awardSubmissions: scoped?.submissions ?? 0,
            awardCertified: scoped?.certifiedArtifactVersions ?? 0,
          });
          setStatsErr(null);
          if (r3.ok && Array.isArray(j3?.items)) setRecent(j3.items);
          else setRecent([]);
        }
      } catch (e: unknown) {
        if (!cancelled) {
          setStats(null);
          setRecent([]);
          setStatsErr((e as Error)?.message || "stats");
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [isMusic]);

  const gradient = isMusic
    ? "linear-gradient(145deg, #1e1b4b 0%, #4c1d95 45%, #7c3aed 100%)"
    : "linear-gradient(145deg, #1c1917 0%, #7f1d1d 48%, #b45309 100%)";
  const accent = isMusic ? "#c4b5fd" : "#fcd34d";
  const planetHref = (() => {
    const params = new URLSearchParams();
    params.set("type", isMusic ? "music" : "movie");
    params.set("preset", isMusic ? "music" : "film");
    params.set("productKey", isMusic ? "aevion_award_music_v1" : "aevion_award_film_v1");
    params.set(
      "title",
      isMusic ? "Заявка на музыкальную премию AEVION" : "Заявка на кинопремию AEVION"
    );
    return `/planet?${params.toString()}`;
  })();
  const artifactType = isMusic ? "music" : "movie";
  const prefix = isMusic ? "aevion_award_music" : "aevion_award_film";
  const oppositeAwardsHref = isMusic ? "/awards/film" : "/awards/music";

  const title = isMusic ? "AEVION Music Awards" : "AEVION Film Awards";
  const tag = isMusic ? "Как Грэмми — для ИИ и цифровой музыки" : "Как Оскар — для ИИ и цифрового кино";
  const body = isMusic
    ? "Отдельная витрина премии для музыкальных работ: подача через Planet (тип music), сертификат compliance и голосование участников экосистемы."
    : "Отдельная витрина премии для кино и видео: подача через Planet (тип movie), сертификат compliance и голосование участников экосистемы.";

  return (
    <main style={{ padding: 0, minHeight: "100vh", background: "#0f172a" }}>
      <section
        style={{
          background: gradient,
          color: "#fff",
          padding: "40px 24px 48px",
        }}
      >
        <div style={{ maxWidth: 720, margin: "0 auto" }}>
          <Wave1Nav variant="dark" />
          <div
            style={{
              display: "inline-block",
              fontSize: 11,
              fontWeight: 800,
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              padding: "6px 12px",
              borderRadius: 999,
              background: "rgba(0,0,0,0.25)",
              border: "1px solid rgba(255,255,255,0.2)",
              marginBottom: 16,
            }}
          >
            Премия Planet · MVP
          </div>
          <h1
            style={{
              fontSize: "clamp(28px, 5vw, 40px)",
              fontWeight: 900,
              lineHeight: 1.1,
              margin: "0 0 12px",
              letterSpacing: "-0.03em",
            }}
          >
            {title}
          </h1>
          <p style={{ fontSize: 17, fontWeight: 700, color: accent, margin: "0 0 16px" }}>{tag}</p>
          <p style={{ fontSize: 16, lineHeight: 1.65, opacity: 0.94, margin: 0 }}>{body}</p>

          <div
            style={{
              marginTop: 22,
              padding: "14px 16px",
              borderRadius: 14,
              background: "rgba(0,0,0,0.22)",
              border: "1px solid rgba(255,255,255,0.18)",
              fontSize: 14,
              lineHeight: 1.55,
            }}
          >
            {statsErr ? (
              <span style={{ opacity: 0.85 }}>Статистика Planet недоступна ({statsErr}).</span>
            ) : stats ? (
              <>
                <div style={{ fontWeight: 800, marginBottom: 8, color: accent }}>Экосистема Planet (live)</div>
                <div>
                  Участников с активным символом (кворум <strong>Y</strong>):{" "}
                  <strong style={{ fontSize: 18 }}>{stats.eligibleParticipants}</strong>
                </div>
                <div style={{ marginTop: 6, opacity: 0.9 }}>
                  Уникальных голосовавших (всё время): <strong>{stats.distinctVotersAllTime}</strong>
                </div>
                <div style={{ marginTop: 6, opacity: 0.85, fontSize: 13 }}>
                  Сертифицированных версий артефактов (вся Planet): {stats.certifiedArtifactVersions}
                </div>
                <div
                  style={{
                    marginTop: 10,
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))",
                    gap: 8,
                  }}
                >
                  <div
                    style={{
                      borderRadius: 10,
                      border: "1px solid rgba(255,255,255,0.2)",
                      background: "rgba(255,255,255,0.08)",
                      padding: "8px 10px",
                    }}
                  >
                    <div style={{ fontSize: 11, opacity: 0.75 }}>Трек: заявок</div>
                    <div style={{ marginTop: 2, fontWeight: 900, fontSize: 18 }}>{stats.awardSubmissions}</div>
                  </div>
                  <div
                    style={{
                      borderRadius: 10,
                      border: "1px solid rgba(255,255,255,0.2)",
                      background: "rgba(255,255,255,0.08)",
                      padding: "8px 10px",
                    }}
                  >
                    <div style={{ fontSize: 11, opacity: 0.75 }}>Трек: сертифицировано</div>
                    <div style={{ marginTop: 2, fontWeight: 900, fontSize: 18 }}>{stats.awardCertified}</div>
                  </div>
                </div>
                <div
                  style={{
                    marginTop: 12,
                    paddingTop: 12,
                    borderTop: "1px solid rgba(255,255,255,0.18)",
                    fontSize: 13,
                    opacity: 0.92,
                  }}
                >
                  <div style={{ fontWeight: 800, marginBottom: 6, color: accent }}>
                    Трек этой премии (productKey prefix)
                  </div>
                  Заявок: <strong>{stats.awardSubmissions}</strong>
                  {" · "}
                  Сертифицировано: <strong>{stats.awardCertified}</strong>
                  <div style={{ marginTop: 4, opacity: 0.8, fontSize: 12 }}>
                    Фильтр API:{" "}
                    <code style={{ color: "#e2e8f0" }}>
                      ?productKeyPrefix={prefix}
                    </code>
                  </div>
                </div>
              </>
            ) : (
              <span style={{ opacity: 0.85 }}>Загрузка статистики Planet…</span>
            )}
          </div>

          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 28 }}>
            <Link
              href={planetHref}
              style={{
                ...btn,
                background: "#fff",
                color: "#0f172a",
                boxShadow: "0 8px 28px rgba(0,0,0,0.25)",
              }}
            >
              Подать работу в Planet →
            </Link>
            <Link
              href="/auth"
              style={{
                ...btn,
                background: "rgba(255,255,255,0.12)",
                color: "#fff",
                border: "1px solid rgba(255,255,255,0.35)",
              }}
            >
              Войти (нужен токен)
            </Link>
            <Link
              href={oppositeAwardsHref}
              style={{
                ...btn,
                background: "transparent",
                color: "#e2e8f0",
                border: "1px solid rgba(255,255,255,0.25)",
              }}
            >
              {isMusic ? "Кинопремия →" : "Музыкальная премия →"}
            </Link>
            <Link
              href="/awards"
              style={{
                ...btn,
                background: "transparent",
                color: "#e2e8f0",
                border: "1px solid rgba(255,255,255,0.25)",
              }}
            >
              Общий хаб премий →
            </Link>
          </div>
        </div>
      </section>

      <section
        style={{
          padding: "28px 24px 14px",
          maxWidth: 720,
          margin: "0 auto",
          color: "#e2e8f0",
          background: "#0f172a",
        }}
      >
        <h2 style={{ color: "#f8fafc", fontSize: 17, fontWeight: 800, margin: "0 0 12px" }}>
          Как подать работу: 3 шага
        </h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 10 }}>
          <article
            style={{
              borderRadius: 12,
              border: "1px solid rgba(148,163,184,0.25)",
              background: "rgba(15,23,42,0.46)",
              padding: "12px 12px 10px",
            }}
          >
            <div style={{ fontSize: 12, color: accent, fontWeight: 800 }}>Шаг 1</div>
            <div style={{ marginTop: 4, fontWeight: 800 }}>Войти через Auth</div>
            <p style={{ margin: "6px 0 0", fontSize: 13, opacity: 0.86, lineHeight: 1.55 }}>
              Нужен токен участника для отправки артефакта и последующей верификации.
            </p>
          </article>
          <article
            style={{
              borderRadius: 12,
              border: "1px solid rgba(148,163,184,0.25)",
              background: "rgba(15,23,42,0.46)",
              padding: "12px 12px 10px",
            }}
          >
            <div style={{ fontSize: 12, color: accent, fontWeight: 800 }}>Шаг 2</div>
            <div style={{ marginTop: 4, fontWeight: 800 }}>Отправить в Planet</div>
            <p style={{ margin: "6px 0 0", fontSize: 13, opacity: 0.86, lineHeight: 1.55 }}>
              Выберите тип <code>{artifactType}</code>, укажите продуктовый ключ и пройдите compliance.
            </p>
          </article>
          <article
            style={{
              borderRadius: 12,
              border: "1px solid rgba(148,163,184,0.25)",
              background: "rgba(15,23,42,0.46)",
              padding: "12px 12px 10px",
            }}
          >
            <div style={{ fontSize: 12, color: accent, fontWeight: 800 }}>Шаг 3</div>
            <div style={{ marginTop: 4, fontWeight: 800 }}>Проверить публичную карточку</div>
            <p style={{ margin: "6px 0 0", fontSize: 13, opacity: 0.86, lineHeight: 1.55 }}>
              После сертификации артефакт появляется в этой ленте и доступен по публичной ссылке.
            </p>
          </article>
        </div>
        <div style={{ marginTop: 10, fontSize: 12, opacity: 0.75 }}>
          Быстрый фильтр Planet: <code style={{ color: "#e2e8f0" }}>?type={artifactType}</code> и{" "}
          <code style={{ color: "#e2e8f0" }}>?productKeyPrefix={prefix}</code>
        </div>
      </section>

      <section
        style={{
          padding: "28px 24px 36px",
          maxWidth: 720,
          margin: "0 auto",
          color: "#e2e8f0",
          borderTop: "1px solid rgba(148,163,184,0.2)",
          background: "#0f172a",
        }}
      >
        <h2 style={{ color: "#f8fafc", fontSize: 17, fontWeight: 800, margin: "0 0 14px" }}>
          Лента сертифицированных работ (этот трек премии)
        </h2>
        {stats && !statsErr && recent.length === 0 ? (
          <p style={{ margin: 0, fontSize: 14, opacity: 0.85, lineHeight: 1.6 }}>
            Пока нет опубликованных сертификатов с префиксом productKey для этой премии. Подайте работу через Planet —
            после прохождения compliance она появится здесь.
          </p>
        ) : null}
        {recent.length > 0 ? (
          <ul style={{ margin: 0, paddingLeft: 18, lineHeight: 1.65, fontSize: 14 }}>
            {recent.map((row) => (
              <li key={row.id} style={{ marginBottom: 8 }}>
                <Link href={`/planet/artifact/${row.id}`} style={{ fontWeight: 800, color: accent }}>
                  {row.submissionTitle || "Без названия"}
                </Link>
                <span style={{ opacity: 0.75 }}>
                  {" "}
                  · v{row.versionNo ?? "?"} ·{" "}
                  <Link href={`/planet/artifact/${row.id}`} style={{ color: "#94a3b8" }}>
                    публичная карточка
                  </Link>
                </span>
              </li>
            ))}
          </ul>
        ) : null}
      </section>

      <section style={{ padding: "32px 24px 48px", maxWidth: 720, margin: "0 auto", color: "#cbd5e1" }}>
        <h2 style={{ color: "#f8fafc", fontSize: 18, fontWeight: 800, marginBottom: 12 }}>Как это связано с Planet</h2>
        <ul style={{ margin: 0, paddingLeft: 20, lineHeight: 1.7, fontSize: 15 }}>
          <li>Один backend и один контур голосов для музыки и кино — различаются тип артефакта и витрина.</li>
          <li>Итоги голосования в перспективе показываются в контексте числа участников Planet (см. AEVION_AWARDS_SPEC).</li>
          <li>Бренды премий — собственные AEVION; формулировки «как Грэмми / Оскар» — про подачу, не про чужие ТЗ.</li>
        </ul>
        <p style={{ marginTop: 20, fontSize: 14, opacity: 0.85 }}>
          Документация: <code style={{ color: "#94a3b8" }}>AEVION_AWARDS_SPEC.md</code>,{" "}
          <code style={{ color: "#94a3b8" }}>AEVION_PLANET_CONCEPT.md</code>
        </p>
      </section>
    </main>
  );
}
