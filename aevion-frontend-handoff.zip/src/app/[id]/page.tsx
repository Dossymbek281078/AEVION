import Link from "next/link";
import { notFound } from "next/navigation";
import { ProductPageShell } from "@/components/ProductPageShell";
import { Wave1Nav } from "@/components/Wave1Nav";
import { apiUrl } from "@/lib/apiBase";

type ModuleRuntime = {
  tier: string;
  primaryPath: string | null;
  apiHints: string[];
  hint: string;
};

type GlobusProject = {
  id: string;
  code: string;
  name: string;
  description: string;
  kind: string;
  status: string;
  priority: number;
  tags: string[];
  runtime?: ModuleRuntime;
};

function ProjectFetchFailed({ id, status }: { id: string; status?: number }) {
  return (
    <main>
      <ProductPageShell maxWidth={980}>
        <Wave1Nav />
        <h1 style={{ fontSize: 24, marginTop: 8 }}>Карточка узла временно недоступна</h1>
        <p style={{ color: "#555", lineHeight: 1.6, maxWidth: 560 }}>
          Не удалось получить данные модуля из API Globus
          {status != null ? ` (HTTP ${status})` : ""}. Убедитесь, что backend запущен (порт 4001), или
          откройте главную — список узлов там подгружается тем же контуром.
        </p>
        <p style={{ fontSize: 13, color: "#777" }}>
          id: <code>{id}</code>
        </p>
        <Link
          href="/"
          style={{
            display: "inline-block",
            marginTop: 16,
            border: "1px solid #111",
            borderRadius: 10,
            padding: "10px 14px",
            textDecoration: "none",
            color: "#111",
            fontWeight: 650,
          }}
        >
          На главную Globus
        </Link>
      </ProductPageShell>
    </main>
  );
}

export default async function ProjectByIdPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }> | { id: string };
  searchParams?: Promise<{ [key: string]: string | string[] | undefined }> | {
    [key: string]: string | string[] | undefined;
  };
}) {
  const p = (await Promise.resolve(params)) as { id: string };
  const id = p.id;

  const sp = (await Promise.resolve(searchParams)) as
    | { [key: string]: string | string[] | undefined }
    | undefined;

  const normalize = (v: unknown): string => {
    if (v == null) return "";
    if (typeof v === "string") return v;
    if (Array.isArray(v) && typeof v[0] === "string") return v[0];
    return "";
  };

  const country = normalize(sp?.country);
  const city = normalize(sp?.city);

  let res: Response;
  try {
    res = await fetch(apiUrl(`/api/globus/projects/${id}`), {
      cache: "no-store",
      signal: AbortSignal.timeout(20_000),
    });
  } catch {
    return <ProjectFetchFailed id={id} />;
  }

  if (res.status === 404) notFound();
  if (!res.ok) return <ProjectFetchFailed id={id} status={res.status} />;

  let project: GlobusProject;
  try {
    project = (await res.json()) as GlobusProject;
  } catch {
    return <ProjectFetchFailed id={id} />;
  }

  const specialLinks: Record<string, string> = {
    qright: "/qright",
    qsign: "/qsign",
    "aevion-ip-bureau": "/bureau",
    qtradeoffline: "/qtrade",
    qcoreai: "/qcoreai",
    "multichat-engine": "/multichat-engine",
    auth: "/auth",
  };

  const actionHref = specialLinks[project.id];

  const qrightPrefill = (() => {
    const qs = new URLSearchParams();
    if (country) qs.set("country", country);
    if (city) qs.set("city", city);
    qs.set("title", `${project.code} • ${project.name}`);
    qs.set("description", project.description);
    // keep kind default ("idea") in QRight UI
    return `/qright?${qs.toString()}`;
  })();

  const qsignPrefillPayload = JSON.stringify(
    {
      schema: "aevion.module.stub.v1",
      moduleId: project.id,
      code: project.code,
      name: project.name,
      country: country || null,
      city: city || null,
      ts: new Date().toISOString(),
    },
    null,
    0
  );
  const qsignPrefill = `/qsign?payload=${encodeURIComponent(qsignPrefillPayload)}`;

  const bureauPrefill = (() => {
    const qs = new URLSearchParams();
    if (country) qs.set("country", country);
    if (city) qs.set("city", city);
    const q = qs.toString();
    return q ? `/bureau?${q}` : "/bureau";
  })();

  return (
    <main>
      <ProductPageShell maxWidth={980}>
      <Wave1Nav />
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontSize: 12, color: "#666" }}>
            {project.code} • {project.kind} • {project.status}
            {project.runtime?.tier ? ` • runtime: ${project.runtime.tier}` : ""}
          </div>
          {project.runtime?.hint ? (
            <div style={{ fontSize: 12, color: "#888", marginTop: 4 }}>{project.runtime.hint}</div>
          ) : null}
          <h1 style={{ fontSize: 26, marginTop: 6, marginBottom: 8 }}>
            {project.name}
          </h1>
        </div>
        <Link
          href="/"
          style={{
            border: "1px solid #111",
            borderRadius: 10,
            padding: "10px 12px",
            textDecoration: "none",
            color: "#111",
            fontWeight: 650,
            alignSelf: "flex-start",
          }}
        >
          Back to Globus
        </Link>
      </div>

      <div style={{ border: "1px solid #ddd", borderRadius: 12, padding: 16 }}>
        <div style={{ color: "#555", lineHeight: 1.6, fontSize: 14 }}>
          {project.description}
        </div>

        <div style={{ marginTop: 12, display: "flex", gap: 12, flexWrap: "wrap" }}>
          <div style={{ border: "1px solid rgba(0,0,0,0.08)", padding: 12, borderRadius: 12, minWidth: 220 }}>
            <div style={{ fontSize: 12, color: "#666" }}>Location (Globus)</div>
            <div style={{ fontWeight: 800, marginTop: 6 }}>
              {city || country ? `${city || "—"}${country ? `, ${country}` : ""}` : "—"}
            </div>
          </div>
          <div style={{ border: "1px solid rgba(0,0,0,0.08)", padding: 12, borderRadius: 12, minWidth: 220 }}>
            <div style={{ fontSize: 12, color: "#666" }}>Future realization place</div>
            <div style={{ fontWeight: 800, marginTop: 6 }}>Construction Portal</div>
          </div>
        </div>

        <div style={{ marginTop: 14, display: "flex", gap: 10, flexWrap: "wrap" }}>
          {actionHref ? (
            <Link
              href={actionHref}
              style={{
                border: "1px solid #111",
                borderRadius: 10,
                padding: "10px 12px",
                textDecoration: "none",
                color: "#111",
                fontWeight: 650,
                background: "rgba(0,0,0,0.03)",
              }}
            >
              Open module
            </Link>
          ) : (
            <div style={{ color: "#666", fontSize: 13, maxWidth: 520, lineHeight: 1.6 }}>
              Отдельная страница MVP для этого модуля ещё в работе — ниже конвейер AEVION даёт уже
              осмысленные шаги (идентичность → реестр → подпись → бюро).
            </div>
          )}

          <Link
            href={qrightPrefill}
            style={{
              border: "1px solid #111",
              borderRadius: 10,
              padding: "10px 12px",
              textDecoration: "none",
              color: "#111",
              fontWeight: 650,
              background: "rgba(0,0,0,0.03)",
            }}
          >
            Создать карточку в QRight на этой локации
          </Link>
        </div>

        <div
          style={{
            marginTop: 20,
            padding: 16,
            borderRadius: 12,
            border: "1px solid rgba(0,80,160,0.2)",
            background: "rgba(0,80,160,0.04)",
          }}
        >
          <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 10, color: "#024" }}>
            Ускорение: одинаковый осмысленный контур для всех 27 модулей
          </div>
          <ol style={{ margin: 0, paddingLeft: 18, color: "#333", fontSize: 13, lineHeight: 1.65 }}>
            <li style={{ marginBottom: 8 }}>
              <Link href="/auth" style={{ fontWeight: 650, color: "#024" }}>
                Auth
              </Link>
              {" — "}
              закрепить владельца для QRight и будущих реестров.
            </li>
            <li style={{ marginBottom: 8 }}>
              <Link href={qrightPrefill} style={{ fontWeight: 650, color: "#024" }}>
                QRight
              </Link>
              {" — "}
              карточка продукта/идеи с привязкой к локации на Globus.
            </li>
            <li style={{ marginBottom: 8 }}>
              <Link href={qsignPrefill} style={{ fontWeight: 650, color: "#024" }}>
                QSign
              </Link>
              {" — "}
              заготовленный JSON модуля; подпись HMAC одним кликом.
            </li>
            <li>
              <Link href={bureauPrefill} style={{ fontWeight: 650, color: "#024" }}>
                IP Bureau
              </Link>
              {" — "}
              подписать объект реестра с учётом локации (deep link).
            </li>
          </ol>
        </div>

        <hr style={{ margin: "16px 0", borderColor: "rgba(0,0,0,0.08)" }} />

        <div style={{ fontSize: 12, color: "#666" }}>
          id: {project.id} • priority: {project.priority}
        </div>
      </div>
      </ProductPageShell>
    </main>
  );
}

